//cal btn
const calBtn = document.querySelector('#calculateBtn');
//input field
const loanAmount = document.querySelector('#loan-amount');
const interestRate = document.querySelector('#interest-rate');
const yearToRepay = document.querySelector('#year-to-repay');
//output field
const outputInterest  = document.getElementById('outputinterest');
const monthlyRepayment  = document.getElementById('monthlyrepayment');
const totalRepayment = document.getElementById('totalrepayment');

calBtn.addEventListener('click', calculate);

function calculate(e){

    const principalAmount = parseFloat(loanAmount.value);
    const calInterest = parseFloat(interestRate.value)/ 100 /12;
    const calPayment = parseFloat(yearToRepay.value)* 12;

    //for monthly payment
    const x = Math.pow(1 + calInterest, calPayment);
    const MP = (principalAmount*x*calInterest)/(x-1);

    if(isFinite(MP)){
      monthlyRepayment.textContent = monthlyRepayment.value = MP.toFixed(2);
      outputInterest.textContent  =  outputInterest.value = (MP * calPayment).toFixed(2);
      totalRepayment.textContent  =  totalRepayment.value = ((MP * calPayment)-principalAmount).toFixed(2);
    }else{
        console.log('please enter numbers');
    }
   
    e.preventDefault();
}