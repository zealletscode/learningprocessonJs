// JavaScript (scripts.js)

  // Loan repayment calculator
  document.addEventListener("DOMContentLoaded", function () {
    const loanAmountInput = document.querySelector("#loan-amount");
    const interestRateInput = document.querySelector("#interest-rate");
    const calculateButton = document.querySelector("#calculate-button");
    const monthlyPaymentResult = document.querySelector("#monthly-payment");
  
    calculateButton.addEventListener("submit", function () {
      const loanAmount = parseFloat(loanAmountInput.value);
      const interestRate = parseFloat(interestRateInput.value);
      const loanTerm = 10; // Fixed 10-year loan term for simplicity
  
      if (!isNaN(loanAmount) && !isNaN(interestRate)) {
        const monthlyInterestRate = interestRate / 100 / 12;
        const monthlyPayments =
          (loanAmount *
            monthlyInterestRate *
            Math.pow(1 + monthlyInterestRate, loanTerm * 12)) /
          (Math.pow(1 + monthlyInterestRate, loanTerm * 12) - 1);
  
        monthlyPaymentResult.textContent = `$${monthlyPayments.toFixed(2)}`;
      } else {
        monthlyPaymentResult.textContent = "Invalid input";
      }
    });
  });
  